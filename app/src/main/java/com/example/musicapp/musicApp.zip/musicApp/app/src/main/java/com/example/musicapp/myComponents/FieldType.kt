package com.example.musicapp.myComponents





enum class FieldType {
    Text, Email, Password, Phone, Number
}

