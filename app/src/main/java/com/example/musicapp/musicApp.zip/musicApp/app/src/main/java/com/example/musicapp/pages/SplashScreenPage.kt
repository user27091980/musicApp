package com.example.musicapp.pages

import android.window.SplashScreen
import androidx.compose.runtime.Composable

@Composable
fun SplashScreen(){

    SplashScreen();

}