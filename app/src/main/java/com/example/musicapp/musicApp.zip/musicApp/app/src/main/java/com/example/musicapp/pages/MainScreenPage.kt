package com.example.musicapp.pages

import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable

@Composable
fun MainScreen(){

    TODO()



}